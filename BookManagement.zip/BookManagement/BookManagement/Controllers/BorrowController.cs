﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using BookBorrowingSystemAPI.Data;
using BookBorrowingSystemAPI.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace BookBorrowingSystemAPI.Controllers
{
    [Route("[controller]")]
    public class BorrowController : Controller
    {
        private readonly BookBorrowContext _context;

        public BorrowController(BookBorrowContext context)
        {
            _context = context;
        }

        // GET: Borrow
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var borrows = await _context.Borrow.ToListAsync();
            return View(borrows); // Returns the list view of borrows
        }

        // GET: Borrow/Details/5
        [HttpGet("Details/{id}")]
        public async Task<IActionResult> Details(int id)
        {
            var borrow = await _context.Borrow.FindAsync(id);
            if (borrow == null)
            {
                return NotFound();
            }
            return View(borrow); // Returns the details view of a specific borrow
        }

        // GET: Borrow/Create
        [HttpGet("Create")]
        public IActionResult Create()
        {
            return View(); // Returns the view for creating a new borrow record
        }

        // POST: Borrow/Create
        [HttpPost("Create")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Borrow borrow)
        {
            if (ModelState.IsValid)
            {
                _context.Add(borrow);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index)); // Redirects to the borrow list
            }
            return View(borrow);
        }

        // GET: Borrow/Edit/5
        [HttpGet("Edit/{id}")]
        public async Task<IActionResult> Edit(int id)
        {
            var borrow = await _context.Borrow.FindAsync(id);
            if (borrow == null)
            {
                return NotFound();
            }
            return View(borrow); // Returns the edit view for a specific borrow
        }

        // POST: Borrow/Edit/5
        [HttpPost("Edit/{id}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, Borrow borrow)
        {
            if (id != borrow.BorrowID)
            {
                return BadRequest();
            }
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(borrow);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BorrowExists(id))
                    {
                        return NotFound();
                    }
                    throw;
                }
                return RedirectToAction(nameof(Index)); // Redirects to the borrow list
            }
            return View(borrow);
        }

        // GET: Borrow/Delete/5
        [HttpGet("Delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var borrow = await _context.Borrow.FindAsync(id);
            if (borrow == null)
            {
                return NotFound();
            }

            return View(borrow); // Returns the delete confirmation view
        }

        // POST: Borrow/Delete/5
        [HttpPost("Delete/{id}"), ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var borrow = await _context.Borrow.FindAsync(id);
            if (borrow != null)
            {
                _context.Borrow.Remove(borrow);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index)); // Redirects to the borrow list
        }

        private bool BorrowExists(int id)
        {
            return _context.Borrow.Any(e => e.BorrowID == id);
        }


    }
}

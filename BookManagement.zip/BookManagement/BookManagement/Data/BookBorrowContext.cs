﻿using Microsoft.EntityFrameworkCore;
using BookBorrowingSystemAPI.Models;

namespace BookBorrowingSystemAPI.Data
{
    public class BookBorrowContext : DbContext
    {
        public BookBorrowContext(DbContextOptions<BookBorrowContext> options) : base(options) { }

        public DbSet<Book> Book { get; set; }
        public DbSet<Borrow> Borrow { get; set; }
    }
}
